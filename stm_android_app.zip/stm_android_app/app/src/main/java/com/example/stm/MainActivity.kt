package com.example.stm

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import android.webkit.WebView
import android.webkit.WebViewClient

class MainActivity : AppCompatActivity() {
    private val mapUrl = "https://maps.app.goo.gl/G1LX8zKrVW89GWNs7"
    private val phoneNumber = "09777895552"
    private val address = "အမှတ် 630 ဂန္ဓမာလမ်း ရွှေလောင်းမြို့"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val webView = findViewById<WebView>(R.id.webView)
        val phoneButton = findViewById<Button>(R.id.phoneButton)
        val addressText = findViewById<TextView>(R.id.addressText)

        // WebView settings
        webView.webViewClient = WebViewClient()
        webView.settings.javaScriptEnabled = true
        webView.loadUrl(mapUrl)

        // Set address text
        addressText.text = address

        // Phone button click to dial phone number
        phoneButton.setOnClickListener {
            val intent = Intent(Intent.ACTION_DIAL)
            intent.data = Uri.parse("tel:$phoneNumber")
            startActivity(intent)
        }
    }
}